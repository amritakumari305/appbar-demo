import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import NavbarComp from './components/NavbarComp';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import About from './components/About';
import Contact from './components/Contact';
import Home from './components/Home';
import Event from './components/Event';
import Gift from './components/Gift';
import EventDetails from './components/EventDetails';
import BookingForm from './components/BookingForm';
import Birthday from './components/Birthday';
import MyGallery from './components/MyGallery';

function App() {
  return (
    <>
      <Router>
        <NavbarComp />
        <Switch>
          <Route path='/' exact component={Home} />
          <Route path='/about' component={About} />
          <Route path="/contact" component={Contact} />
          <Route path="/event" component={Event} />
          <Route path="/Gift" component={Gift} />
          <Route path="/eventDetails" component={EventDetails} />
         <Route path="/bookingForm" component={BookingForm} />
         <Route path="/MyGallery" component={MyGallery} />
         <Route path="/birthday" component={Birthday} />

        </Switch>

      </Router>
    </>
  );
}

export default App;
