import React, { Component } from 'react';  
class ContactComponent extends React.Component {  
  constructor(props) {  
      super(props);  
      this.updateSubmit = this.updateSubmit.bind(this);  
      this.input = React.createRef();  
  }  
  updateSubmit(event) {  
      alert('You have entered the UserName and CompanyName successfully.');  
      event.preventDefault();  
  }  
  render() {  
    return (
        <div>
            <section className="pb-5">
                <div className="container">
                    <div className="row">

                        <div className="col-md-7">
                            <div className="contact-form">
                                <div class="section-title clearfix mb-4">
                                    <h3 class="title">Get The Party Started</h3>
                                    <p>As the premier event planning company in the area. Each event and client is unique and we believe our services should be as well.</p>
                                </div>

                                <form onSubmit={this.updateSubmit}>
                                    <h1>Uncontrolled Form Example</h1>
                                    <label>Name:
                                        <input type="text" ref={this.input} />
                                    </label>
                                    <label>
                                        CompanyName:
                                        <input type="text" ref={this.input} />
                                    </label>
                                    <input type="submit" value="Submit" />
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    )
  }
}

export default ContactComponent;
