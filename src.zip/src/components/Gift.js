import React, { Component } from 'react'
import Footer from './Footer'

export default class Gift extends Component {
    render() {
        return (
            <div>
                 <Footer /> 
            </div>
        )
    }
}
