import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import ContactComponent from './ContactComponent';
import Footer from './Footer';

export default class Contact extends Component {
    render() {
        return (
            <>
                <section className="py-5 bg-breadcrumb">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="breadcrumb-item  text-center">
                                    <h4 className="breadcrumb-title">Contact Us</h4>
                                    <div>
                                        <ul className="list-unstyled">
                                            <li className="d-inline"><Link to="/">Home</Link></li>
                                            <li className="d-inline"><Link to="/"> / </Link></li>
                                            <li className="d-inline text-white"><Link to="/"></Link>Contact Us</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="pt-5 pb-3">
                    <div className="container">
                        <div class="row">
                            <div class="col-lg-9 col-md-9">
                                <div class="section-title clearfix">
                                    <h4>GET IN TOUCH</h4>
                                    <h2 class="title">Contact Us</h2>
                                    <div class="heading-seperator"><span></span></div>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’type specimen book.</p>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3">

                                <button class="btn-md btn-round mb-3" title="button">View Events</button>
                            </div>
                        </div>


                        <div class="row mt-5">
                            <div class="col-md-4">
                                <div class="featured-box style2 left-icon icon-align-top">
                                    <div class="featured-icon">
                                        <div class="evt-icon evt-icon_element-size-sm evt-icon_element-color-skincolor evt-icon_element-style-round">
                                            <i class="fas fa-headphones-alt"></i>
                                        </div>
                                    </div>
                                    <div class="featured-content">
                                        <div class="featured-title">
                                            <h5>Phone</h5>
                                        </div>
                                        <div class="featured-desc">
                                            <p>Phone 01:+1800 565 5658,<br />Phone 01:+1800 565 5658,</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="featured-box style2 left-icon icon-align-top">
                                    <div class="featured-icon">
                                        <div class="evt-icon evt-icon_element-size-sm evt-icon_element-color-skincolor evt-icon_element-style-round">
                                            <i class="fas fa-map-marker-alt"></i>
                                        </div>
                                    </div>
                                    <div class="featured-content">
                                        <div class="featured-title">
                                            <h5>Address</h5>
                                        </div>
                                        <div class="featured-desc">
                                            <p>254 Monteral Ave musiam Staren<br />New Jersey USA 789 456</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="featured-box style2 left-icon icon-align-top">
                                    <div class="featured-icon">
                                        <div class="evt-icon evt-icon_element-size-sm evt-icon_element-color-skincolor evt-icon_element-style-round">
                                            <i class="far fa-envelope"></i>
                                        </div>
                                    </div>
                                    <div class="featured-content">
                                        <div class="featured-title">
                                            <h5>E-Mail</h5>
                                        </div>
                                        <div class="featured-desc">
                                            <p>info@example.com,<br />planwey2@gmail.com</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="pb-5">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-5">
                                <div className="map">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.6834031057483!2d75.75614591491477!3d26.881798067891935!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db4f798006cbb%3A0x1ba3f77f1a1f2382!2sCoral%20IT%20Solutions!5e0!3m2!1sen!2sin!4v1631178157130!5m2!1sen!2sin" width="100%" height="530px" allowfullscreen="" loading="lazy"></iframe>
                                </div>
                            </div>
                            <div className="col-md-7">
                                <div className="contact-form">
                                    <div class="section-title clearfix mb-4">
                                        <h3 class="title">Get The Party Started</h3>
                                        <p>As the premier event planning company in the area. Each event and client is unique and we believe our services should be as well.</p>
                                    </div>

                                    <form id="contactform" class="contactform wrap-form clearfix" method="post" action="#" novalidate="novalidate">
                                        <div className="row">
                                            <div class="col-md-6">
                                                <label htmlFor="name">
                                                    <i class="far fa-user"></i>
                                                    <span class="ttm-form-control">
                                                        <input class="text-input" name="name" type="text" value="" placeholder="Your Name:*" required="required" />
                                                    </span>
                                                </label>
                                            </div>
                                            <div class="col-md-6">
                                                <label htmlFor="email">
                                                    <i class="far fa-envelope"></i>
                                                    <span class="ttm-form-control">
                                                        <input class="text-input" name="email" type="text" value="" placeholder="Your email-id:*" required="required" />
                                                    </span>
                                                </label>
                                            </div>
                                            <div class="col-md-6">
                                                <label htmlFor="venue">
                                                    <i class="fas fa-map-marker-alt"></i>
                                                    <span class="ttm-form-control">
                                                        <input class="text-input" name="venue" type="text" value="" placeholder="Venue" required="required" />
                                                    </span>
                                                </label>
                                            </div>
                                            <div class="col-md-6">
                                                <label htmlFor="phone">
                                                    <i class="fas fa-mobile-alt"></i>
                                                    <span class="ttm-form-control">
                                                        <input class="text-input" name="phone" type="text" value="" placeholder="Your Number:*" required="required" />
                                                    </span>
                                                </label>
                                            </div>
                                            <div class="col-md-12">
                                                <label htmlFor="">
                                                    <i class="far fa-comment-alt"></i>
                                                    <span class="ttm-form-control">
                                                        <textarea class="text-area" name="message" placeholder="Your Message:*" required="required"></textarea>
                                                    </span>
                                                </label>
                                            </div>
                                            <input name="submit" type="submit" value="Make a Reservation" class="btn-md btn-round mt-2" id="submit" title="Make a Reservation" />

                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
               <ContactComponent/>
                <Footer />
            </>
        )
    }
}
