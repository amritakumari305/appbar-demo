import React, { Component } from 'react';
import EventSlider from './EventSlider';
import HomeInnr from './HomeInnr';
import Slider from './Slider';
import ClientSlider from './ClientSlider';
import './Slider.css';
import Footer from './Footer';
import { Link } from 'react-router-dom';

export default class Home extends Component {
    render() {
        return (
            <>
                <div className="social-cons">
                    <ul className="list-unstyled">
                        <li><Link to="/"><i class="fab fa-facebook-f"></i><span>Facebook</span></Link></li>
                        <li><Link to="/"><i class="fab fa-twitter"></i><span>Twitter</span></Link></li>
                        <li><Link to="/"><i class="fab fa-instagram"></i><span>Instagram</span></Link></li>
                        <li><Link to="/"><i class="fab fa-linkedin-in"></i><span>Linkedin</span></Link></li>
                        <li><Link to="/"><i class="fab fa-google"></i><span>Google</span></Link></li>
                        <li><Link to="/"><i class="fab fa-youtube"></i><span>Youtube</span></Link></li>
                    </ul>
                </div>
                
                <Slider />
                <HomeInnr />
                <EventSlider />
                <ClientSlider />
                <Footer />
            </>
        )
    }
}
