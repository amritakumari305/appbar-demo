import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import himg from '../headicon.png';
import Footer from './Footer';

export default class About extends Component {
    render() {
        return (
            <>
                <section className="py-5 bg-breadcrumb">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="breadcrumb-item  text-center">
                                    <h4 className="breadcrumb-title">About Us</h4>
                                    <div>
                                        <ul className="list-unstyled">
                                            <li className="d-inline"><Link to="/">Home</Link></li>
                                            <li className="d-inline"><Link to="/"> / </Link></li>
                                            <li className="d-inline text-white"><Link to="/"></Link>About Us</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>


                <section id="about">
                    <div className="container py-4">
                        <div className="row">
                            <div className="col-md-10 offset-md-1 text-center">
                                <img src={himg} alt="" />
                                <h2 className="event-heading mt-3">Welcome to<span class="text-primary"> Coral Event</span></h2>
                                <p className="event-subtitle">From Wedding Functions to Birthday Parties or Corporate Events to Musical Functions,<br />
                                    We offer full range of Events Management Services that scale to your needs &amp; budget.
                                </p>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-4">
                                <div class="event-advantages event-advantages-1">
                                    <div class="event-advantages__icon text-primary"><i class="fas fa-puzzle-piece"></i></div>
                                    <div class="event-advantages__inner">
                                        <h3 class="event-advantages__title">Great Services</h3>
                                        <div class="event-advantages__info">Corem ipsum dolor sit amet consectetur elit sed lusm tempor incididunt ut labore et dolore mag aliqua enima minim veniam quis nostrud exercitation</div>

                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div class="event-advantages event-advantages-1">
                                    <div class="event-advantages__icon text-primary"><i class="far fa-user"></i></div>
                                    <div class="event-advantages__inner">
                                        <h3 class="event-advantages__title">Great People</h3>
                                        <div class="event-advantages__info">Corem ipsum dolor sit amet consectetur elit sed lusm tempor incididunt ut labore et dolore mag aliqua enima minim veniam quis nostrud exercitation</div>

                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div class="event-advantages event-advantages-1">
                                    <div class="event-advantages__icon text-primary"><i class="far fa-thumbs-up"></i></div>
                                    <div class="event-advantages__inner">
                                        <h3 class="event-advantages__title">Great Ideas</h3>
                                        <div class="event-advantages__info">Corem ipsum dolor sit amet consectetur elit sed lusm tempor incididunt ut labore et dolore mag aliqua enima minim veniam quis nostrud exercitation</div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                
                <Footer />
            </>
        )
    }
}
