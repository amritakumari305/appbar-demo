import React, { Component } from 'react';
import { Navbar, Container, Nav, NavDropdown} from 'react-bootstrap';
import { Link } from 'react-router-dom';
import wlogo from '../logo.png';
import './NavbarComp.css';

export default class NavbarComp extends Component {
    render() {
        return (

            <div>
                <header>
                    
                    <div className="top_header">
                        <Navbar bg="light" variant={"dark"} expand="lg">
                            <Container>
                                <Navbar.Brand as={Link} to={"/"}><img src={wlogo} alt="W-Logo" width="170" /></Navbar.Brand>
                                <Navbar.Toggle aria-controls="navbarScroll" />
                                <Navbar.Collapse id="navbarScroll">
                                    <Nav className="mx-auto">
                                        <Nav.Link as={Link} to={"/"}>Home</Nav.Link>
                                        <Nav.Link as={Link} to={"/about"}>About</Nav.Link>
                                        <Nav.Link as={Link} to={"/contact"}>Contact</Nav.Link>

                                        <NavDropdown title="Services" id="navbarScrollingDropdown">
                                            <NavDropdown.Item as={Link} to={"/birthday"}>Birthday Event</NavDropdown.Item>
                                            <NavDropdown.Item as={Link} to={"/aniversary"}>Anniversary Party</NavDropdown.Item>
                                            <NavDropdown.Item as={Link} to={"/"}>Babyshower Event</NavDropdown.Item>
                                            <NavDropdown.Item as={Link} to={"/"}>Private Party</NavDropdown.Item>
                                            <NavDropdown.Divider />
                                            <NavDropdown.Item as={Link} to={"/"}>Festival Event</NavDropdown.Item>
                                            <NavDropdown.Item as={Link} to={"/"}>Engagement Party</NavDropdown.Item>
                                        </NavDropdown>
                                        <Nav.Link as={Link} to={"/event"}>Event</Nav.Link>
                                        <Nav.Link as={Link} to={"/MyGallery"}>Gallery</Nav.Link>
                                        <Nav.Link as={Link} to={"/gift"}>Gift</Nav.Link>
                                    </Nav>
                                    <div className="d-flex">
                                        {/* <Button variant="outline-success btn-lg ml-2 text-dark">Book Us</Button> */}
                                        <button class="btn-md btn-round ml-2 mt-0" title="button" onClick={()=> window.open("bookingForm")}>Book Now</button>
                                    </div>
                                </Navbar.Collapse>
                            </Container>
                        </Navbar>
                    </div>
                </header>

                
            </div>




        )
    }
}

