import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Footer from './Footer';
import Pagination from './Pagination';

export default class Event extends Component {
    render() {
        return (
            <>

                <section className="py-5 bg-breadcrumb">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="breadcrumb-item  text-center">
                                    <h4 className="breadcrumb-title">Our Events</h4>
                                    <div>
                                        <ul className="list-unstyled">
                                            <li className="d-inline"><Link to="/">Home</Link></li>
                                            <li className="d-inline"><Link to="/"> / </Link></li>
                                            <li className="d-inline text-white"><Link to="/"></Link>Our Events</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>


                <section className="upcoming-event-section py-5">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-6 col-lg-4 mb-3">

                                <div className="upcoming-event-imagebox">
                                    <div className="upcoming-thumbnail">
                                        <img className="img-fluid" src="images/s1.jpg" alt="img" />
                                    </div>
                                    <div className="upcoming-bottom-content text-left position-relative">
                                        <div className="upcoming-box-post-date upcoming-bgcolor-skincolor">
                                            <span className="upcoming-entry-date">
                                                <time className="upcoming-date" datetime="2019-01-16T07:07:55+00:00">06<span className="entry-month entry-year">aug</span></time>
                                            </span>
                                        </div>
                                        <div class="upcoming-title">
                                            <h5><Link to="/eventDetails">Product Launch Reamold</Link></h5>
                                        </div>
                                        <div class="upcoming-desc">
                                            <p>It is a long established fact that a reader will be distracted by the readable.</p>
                                        </div>
                                        <div class="upcoming-meta">
                                            <span className="upcoming-meta-line">
                                                <i className="fa fa-map-marker-alt"></i>
                                                Manhamman, New Yok
                                            </span>
                                        </div>
                                        <div class="upcoming-desc-footer">
                                            <Link className="upcoming-btn btn-inline" to="/eventDetails">See Details<i class="fas fa-arrow-right"></i></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="col-md-6 col-lg-4 mb-3">

                                <div className="upcoming-event-imagebox">
                                    <div className="upcoming-thumbnail">
                                        <img className="img-fluid" src="images/s1.jpg" alt="img" />
                                    </div>
                                    <div className="upcoming-bottom-content text-left position-relative">
                                        <div className="upcoming-box-post-date upcoming-bgcolor-skincolor">
                                            <span className="upcoming-entry-date">
                                                <time className="upcoming-date" datetime="2019-01-16T07:07:55+00:00">06<span className="entry-month entry-year">aug</span></time>
                                            </span>
                                        </div>
                                        <div class="upcoming-title">
                                            <h5><Link to="/">Product Launch Reamold</Link></h5>
                                        </div>
                                        <div class="upcoming-desc">
                                            <p>It is a long established fact that a reader will be distracted by the readable.</p>
                                        </div>
                                        <div class="upcoming-meta">
                                            <span className="upcoming-meta-line">
                                                <i className="fa fa-map-marker-alt"></i>
                                                Manhamman, New Yok
                                            </span>
                                        </div>
                                        <div class="upcoming-desc-footer">
                                            <Link className="upcoming-btn btn-inline" to="/">See Details<i class="fas fa-arrow-right"></i></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div className="col-md-6 col-lg-4 mb-3">

                                <div className="upcoming-event-imagebox">
                                    <div className="upcoming-thumbnail">
                                        <img className="img-fluid" src="images/s1.jpg" alt="img" />
                                    </div>
                                    <div className="upcoming-bottom-content text-left position-relative">
                                        <div className="upcoming-box-post-date upcoming-bgcolor-skincolor">
                                            <span className="upcoming-entry-date">
                                                <time className="upcoming-date" datetime="2019-01-16T07:07:55+00:00">06<span className="entry-month entry-year">aug</span></time>
                                            </span>
                                        </div>
                                        <div class="upcoming-title">
                                            <h5><Link to="/">Product Launch Reamold</Link></h5>
                                        </div>
                                        <div class="upcoming-desc">
                                            <p>It is a long established fact that a reader will be distracted by the readable.</p>
                                        </div>
                                        <div class="upcoming-meta">
                                            <span className="upcoming-meta-line">
                                                <i className="fa fa-map-marker-alt"></i>
                                                Manhamman, New Yok
                                            </span>
                                        </div>
                                        <div class="upcoming-desc-footer">
                                            <Link className="upcoming-btn btn-inline" to="/">See Details<i class="fas fa-arrow-right"></i></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>


                    </div>
                </section>
                <Pagination />

                <Footer />
            </>
        )
    }
}
