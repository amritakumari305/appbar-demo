import React, { Component } from 'react';
import './Slider.css';
import { Link } from 'react-router-dom';

export default class Footer extends Component {
    render() {
        return (
            <div>

                <footer>
                    <div className="container">
                        <div className="row pt-5 pb-4">
                            <div className="col-md-6">
                                <div className="f-weidth">
                                    <h5 className="title">Our Company</h5>
                                    <p>
                                        Here you can use rows and columns here to organize your footer
                                        content. <br/>Here you can use rows and columns here to organize.
                                    </p>
                                    <p>
                                        <span>Address : </span> <span>Here you can use rows and columns here to organize</span>
                                    </p>
                                    <p>
                                        <span>E-Mail : </span> <span>coralitsolution.com</span>
                                    </p>
                                    <p>
                                        <span>Number : </span> <span>+91-987-876-8765</span>
                                    </p>
                                </div>
                            </div>
                            <div className="col-md-3 col-sm-6 col-6">
                                <h5 className="title">Links</h5>
                                <ul>
                                    <li className="list-unstyled">
                                        <Link to='/'>Home</Link>

                                    </li>
                                    <li className="list-unstyled">
                                        <Link to='/contact'>Contact Us</Link>

                                    </li>
                                    <li className="list-unstyled">
                                        <Link to='/about'>About Us</Link>

                                    </li>
                                    <li className="list-unstyled">
                                        <Link to='/event'>Events</Link>

                                    </li>
                                    <li className="list-unstyled">
                                        <Link to='/gift'>Gift</Link>

                                    </li>
                                    <li className="list-unstyled">
                                        <Link to='/MyGallery'>Gallery</Link>

                                    </li>
                                </ul>
                            </div>
                            <div className="col-md-3 col-sm-6 col-6">
                                <h5 className="title">Links</h5>
                                <ul>
                                    <li className="list-unstyled">
                                        <Link to='/birthday'>Birthday Event</Link>

                                    </li>
                                    <li className="list-unstyled">
                                        <Link to='/birthday'>Private Event</Link>

                                    </li>
                                    <li className="list-unstyled">
                                        <Link to='/birthday'>Baby Shower</Link>

                                    </li>
                                    <li className="list-unstyled">
                                        <Link to='/birthday'>Anniversary Party</Link>

                                    </li>
                                    <li className="list-unstyled">
                                        <Link to='/birthday'>Festival Event</Link>

                                    </li>
                                    <li className="list-unstyled">
                                        <Link to='/birthday'>Engagement Party</Link>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className="footer-copyright text-center pt-3 pb-1">
                        <div className="container">
                            <p>&copy; {new Date().getFullYear()} Copyright : <Link to='/'> Coral IT Solution </Link></p>
                        </div>
                    </div>
                </footer>

            </div>
        )
    }
}
