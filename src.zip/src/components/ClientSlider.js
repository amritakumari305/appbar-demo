import React, { Component } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";
import './Slider.css';
import himg from '../headicon.png';

export default class Testimonials extends Component {
    render() {
        return (
            <>
                <section id="testimonials">
                    <div class="container py-4">
                        <div className="row">
                            <div className="col-md-10 offset-md-1 text-center heading-bg">
                                <img src={himg} alt="" />
                                <h2 className="event-heading mt-3">Clients   <span class="text-primary"> Feedback </span></h2>
                                <p className="event-subtitle">We make your events smart &amp; impactful by personalised event management services.
                                </p>
                            </div>
                        </div>

                        <div className="row">
                            <div className="col-md-12">
                                <Carousel
                                    showArrows={true}
                                    infiniteLoop={true}
                                    showThumbs={false}
                                    showStatus={false}
                                    autoPlay={true}
                                    interval={6100}
                                >
                                    <div>

                                        <div className="myCarousel">
                                            <h3>Shirley Fultz</h3>
                                            <h4>Designer</h4>
                                            <p>
                                                It's freeing to be able to catch up on customized news and not be
                                                distracted by a social media element on the same site.  distracted by a social media element on the same site
                                            </p>
                                        </div>
                                    </div>

                                    <div>

                                        <div className="myCarousel">
                                            <h3>Daniel Keystone</h3>
                                            <h4>Designer</h4>
                                            <p>
                                                The simple and intuitive design makes it easy for me use. I highly
                                                recommend Fetch to my peers.
                                            </p>
                                        </div>
                                    </div>
                                    

                                    <div>

                                        <div className="myCarousel">
                                            <h3>Theo Sorel</h3>
                                            <h4>Designer</h4>
                                            <p>
                                                I enjoy catching up with Fetch on my laptop, or on my phone when
                                                I'm on the go!
                                            </p>
                                        </div>
                                    </div>
                                </Carousel>
                            </div>
                        </div>
                    </div>
                </section>
            </>
        );
    }
}

