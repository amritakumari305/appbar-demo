import React, { Component } from 'react'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import './Slider.css';
import himg from '../headicon.png';

export default class EventSlider extends Component {
    render() {
        const settings = {
            dots: false,
            infinite: true,
            speed: 800,
            autoplay: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }

            ]
        };
        return (
            <div>
                <section id="events">
                    <div className="container py-4">
                        <div className="row">
                            <div className="col-md-10 offset-md-1 text-center heading-bg">
                                <img src={himg} alt="" />
                                <h2 className="event-heading mt-3">Latest Awesome  <span class="text-primary"> Events </span></h2>
                                <p className="event-subtitle">We make your events smart &amp; impactful by personalised event management services.
                                </p>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-12">

                                <Slider {...settings}>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>The Ronaldos Music Festival</h5>
                                            <div class="ttm-box-meta">
                                                <span class="ttm-event-meta-item ttm-event-date">
                                                    <i class="fas fa-clock"></i>
                                                    <span class="ttm-event-meta-dtstart"> November 28 </span>
                                                    <span class="sep">-</span>
                                                    <span class="ttm-event-meta-dtend">  8:00 am - 5:00 pm </span>
                                                </span>
                                                <div class="tribe-events-vanue">
                                                    <i class="fa fa-map-marker"></i> Manhamman, New Yok
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>The Ronaldos Music Festival</h5>
                                            <div class="ttm-box-meta">
                                                <span class="ttm-event-meta-item ttm-event-date">
                                                    <i class="fas fa-clock"></i>
                                                    <span class="ttm-event-meta-dtstart"> November 28 </span>
                                                    <span class="sep">-</span>
                                                    <span class="ttm-event-meta-dtend">  8:00 am - 5:00 pm </span>
                                                </span>
                                                <div class="tribe-events-vanue">
                                                    <i class="fa fa-map-marker"></i> Manhamman, New Yok
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>The Ronaldos Music Festival</h5>
                                            <div class="ttm-box-meta">
                                                <span class="ttm-event-meta-item ttm-event-date">
                                                    <i class="fas fa-clock"></i>
                                                    <span class="ttm-event-meta-dtstart"> November 28 </span>
                                                    <span class="sep">-</span>
                                                    <span class="ttm-event-meta-dtend">  8:00 am - 5:00 pm </span>
                                                </span>
                                                <div class="tribe-events-vanue">
                                                    <i class="fa fa-map-marker"></i> Manhamman, New Yok
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>The Ronaldos Music Festival</h5>
                                            <div class="ttm-box-meta">
                                                <span class="ttm-event-meta-item ttm-event-date">
                                                    <i class="fas fa-clock"></i>
                                                    <span class="ttm-event-meta-dtstart"> November 28 </span>
                                                    <span class="sep">-</span>
                                                    <span class="ttm-event-meta-dtend">  8:00 am - 5:00 pm </span>
                                                </span>
                                                <div class="tribe-events-vanue">
                                                    <i class="fa fa-map-marker"></i> Manhamman, New Yok
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>The Ronaldos Music Festival</h5>
                                            <div class="ttm-box-meta">
                                                <span class="ttm-event-meta-item ttm-event-date">
                                                    <i class="fas fa-clock"></i>
                                                    <span class="ttm-event-meta-dtstart"> November 28 </span>
                                                    <span class="sep">-</span>
                                                    <span class="ttm-event-meta-dtend">  8:00 am - 5:00 pm </span>
                                                </span>
                                                <div class="tribe-events-vanue">
                                                    <i class="fa fa-map-marker"></i> Manhamman, New Yok
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>The Ronaldos Music Festival</h5>
                                            <div class="ttm-box-meta">
                                                <span class="ttm-event-meta-item ttm-event-date">
                                                    <i class="fas fa-clock"></i>
                                                    <span class="ttm-event-meta-dtstart"> November 28 </span>
                                                    <span class="sep">-</span>
                                                    <span class="ttm-event-meta-dtend">  8:00 am - 5:00 pm </span>
                                                </span>
                                                <div class="tribe-events-vanue">
                                                    <i class="fa fa-map-marker"></i> Manhamman, New Yok
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>The Ronaldos Music Festival</h5>
                                            <div class="ttm-box-meta">
                                                <span class="ttm-event-meta-item ttm-event-date">
                                                    <i class="fas fa-clock"></i>
                                                    <span class="ttm-event-meta-dtstart"> November 28 </span>
                                                    <span class="sep">-</span>
                                                    <span class="ttm-event-meta-dtend">  8:00 am - 5:00 pm </span>
                                                </span>
                                                <div class="tribe-events-vanue">
                                                    <i class="fa fa-map-marker"></i> Manhamman, New Yok
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>The Ronaldos Music Festival</h5>
                                            <div class="ttm-box-meta">
                                                <span class="ttm-event-meta-item ttm-event-date">
                                                    <i class="fas fa-clock"></i>
                                                    <span class="ttm-event-meta-dtstart"> November 28 </span>
                                                    <span class="sep">-</span>
                                                    <span class="ttm-event-meta-dtend">  8:00 am - 5:00 pm </span>
                                                </span>
                                                <div class="tribe-events-vanue">
                                                    <i class="fa fa-map-marker"></i> Manhamman, New Yok
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </Slider>

                            </div>
                        </div>
                    </div>
                </section>
            </div>
        )
    }
}
