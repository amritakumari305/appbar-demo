import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Footer from './Footer';
import himg from '../headicon.png';

export default class BookingForm extends Component {
    render() {
        return (
            <div>
                <section className="py-5 bg-breadcrumb">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="breadcrumb-item  text-center">
                                    <h4 className="breadcrumb-title">Booking</h4>
                                    <div>
                                        <ul className="list-unstyled">
                                            <li className="d-inline"><Link to="/">Home</Link></li>
                                            <li className="d-inline"><Link to="/"> / </Link></li>
                                            <li className="d-inline text-white"><Link to="/"></Link>Booking</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="py-5">
                    <div className="container">
                        <div className="row">

                            <div className="col-md-6 offset-md-3">
                                <div className="contact-form">
                                    <div class="section-title text-center mb-4">
                                        <img src={himg} alt="" />
                                        <h3 class="title mt-3">Get The Party Started</h3>
                                        <p>As the premier event planning company in the area.</p>
                                    </div>
                                    <hr />
                                    <form id="contactform" class="contactform wrap-form clearfix" method="post" action="#" novalidate="novalidate">
                                        <div className="row">
                                            <div class="col-md-6">
                                                <label htmlFor="name">
                                                    <i class="far fa-user"></i>
                                                    <span class="ttm-form-control">
                                                        <input class="text-input" name="name" type="text" value="" placeholder="Your Name:*" required="required" />
                                                    </span>
                                                </label>
                                            </div>
                                            <div class="col-md-6">
                                                <label htmlFor="email">
                                                    <i class="far fa-envelope"></i>
                                                    <span class="ttm-form-control">
                                                        <input class="text-input" name="email" type="text" value="" placeholder="Your email-id:*" required="required" />
                                                    </span>
                                                </label>
                                            </div>
                                            <div class="col-md-6">
                                                <label htmlFor="venue">
                                                    <i class="fas fa-map-marker-alt"></i>
                                                    <span class="ttm-form-control">
                                                        <input class="text-input" name="venue" type="text" value="" placeholder="Venue" required="required" />
                                                    </span>
                                                </label>
                                            </div>
                                            <div class="col-md-6">
                                                <label htmlFor="phone">
                                                    <i class="fas fa-mobile-alt"></i>
                                                    <span class="ttm-form-control">
                                                        <input class="text-input" name="phone" type="text" value="" placeholder="Your Number:*" required="required" />
                                                    </span>
                                                </label>
                                            </div>
                                            <div class="col-md-6">
                                                <label htmlFor="types">
                                                    <i class="fas fa-glass-cheers"></i>
                                                    <span class="ttm-form-control">

                                                        <select class="text-input" name="types" aria-label="Default select example" required="required">
                                                            <option selected>Select Type</option>
                                                            <option value="1">One</option>
                                                            <option value="2">Two</option>
                                                            <option value="3">Three</option>
                                                        </select>
                                                    </span>
                                                </label>
                                            </div>

                                            <div class="col-md-6">
                                                <label htmlFor="date">
                                                    <i class="far fa-calendar-alt"></i>
                                                    <span class="ttm-form-control">
                                                        <input class="text-input" name="date" type="date" value="" placeholder="Enter Date:*" required="required" />
                                                    </span>
                                                </label>
                                            </div>
                                            <div class="col-md-12">
                                                <label htmlFor="message">
                                                    <i class="far fa-comment-alt"></i>
                                                    <span class="ttm-form-control">
                                                        <textarea class="text-area" name="message" placeholder="Extera Info:*" required="required"></textarea>
                                                    </span>
                                                </label>
                                            </div>
                                            <input name="submit" type="submit" value="Make a Reservation" class="btn-md btn-round mt-2" id="submit" title="Make a Reservation" />

                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <Footer />
            </div>
        )
    }
}
