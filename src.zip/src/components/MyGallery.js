import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Footer from './Footer';
import 'photoswipe/dist/photoswipe.css'
import 'photoswipe/dist/default-skin/default-skin.css'
import { Gallery, Item } from 'react-photoswipe-gallery'

export default class MyGallery extends Component {
    render() {

        return (
            <div>
                <section className="py-5 bg-breadcrumb">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="breadcrumb-item  text-center">
                                    <h4 className="breadcrumb-title">Gallery</h4>
                                    <div>
                                        <ul className="list-unstyled">
                                            <li className="d-inline"><Link to="/">Home</Link></li>
                                            <li className="d-inline"><Link to="/"> / </Link></li>
                                            <li className="d-inline text-white"><Link to="/">Gallery</Link></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="py-5">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <Gallery>
                                    <div className="row">
                                        <div className="col-md-4">
                                            <Item
                                                original="https://placekitten.com/1024/768?image=1"
                                                thumbnail="https://placekitten.com/1024/768?image=1"
                                                width="1024"
                                                height="768"
                                            >
                                                {({ ref, open }) => (
                                                    <img ref={ref} onClick={open} src="https://placekitten.com/1024/768?image=1" width="100%" className="mb-4" />
                                                )}
                                            </Item>
                                            
                                        </div>
                                        <div className="col-md-4">
                                            
                                            <Item
                                                original="https://placekitten.com/1024/768?image=2"
                                                thumbnail="https://placekitten.com/1024/768?image=2"
                                                width="1024"
                                                height="768"
                                            >
                                                {({ ref, open }) => (
                                                    <img ref={ref} onClick={open} src="https://placekitten.com/1024/768?image=2" width="100%" className="mb-4" />
                                                )}
                                            </Item>
                                        </div>

                                        <div className="col-md-4">
                                            
                                            <Item
                                                original="https://placekitten.com/1024/768?image=1"
                                                thumbnail="https://placekitten.com/1024/768?image=1"
                                                width="1024"
                                                height="768"
                                            >
                                                {({ ref, open }) => (
                                                    <img ref={ref} onClick={open} src="https://placekitten.com/1024/768?image=1" width="100%" className="mb-4" />
                                                )}
                                            </Item>
                                        </div>
                                        <div className="col-md-4">
                                            
                                            <Item
                                                original="https://placekitten.com/1024/768?image=2"
                                                thumbnail="https://placekitten.com/1024/768?image=2"
                                                width="1024"
                                                height="768"
                                            >
                                                {({ ref, open }) => (
                                                    <img ref={ref} onClick={open} src="https://placekitten.com/1024/768?image=2" width="100%" className="mb-4" />
                                                )}
                                            </Item>
                                        </div>
                                        <div className="col-md-4">
                                            
                                            <Item
                                                original="https://placekitten.com/1024/768?image=1"
                                                thumbnail="https://placekitten.com/1024/768?image=1"
                                                width="1024"
                                                height="768"
                                            >
                                                {({ ref, open }) => (
                                                    <img ref={ref} onClick={open} src="https://placekitten.com/1024/768?image=1" width="100%" className="mb-4" />
                                                )}
                                            </Item>
                                        </div>
                                        <div className="col-md-4">
                                            
                                            <Item
                                                original="https://placekitten.com/1024/768?image=2"
                                                thumbnail="https://placekitten.com/1024/768?image=2"
                                                width="1024"
                                                height="768"
                                            >
                                                {({ ref, open }) => (
                                                    <img ref={ref} onClick={open} src="https://placekitten.com/1024/768?image=2" width="100%" className="mb-4" />
                                                )}
                                            </Item>
                                        </div>
                                        
                                    </div>
                                </Gallery>
                            </div>
                        </div>
                    </div>
                </section>

                <Footer />
            </div>
        )
    }
}
