import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Footer from './Footer';
import himg from '../headicon.png';
import PartyTheme from './PartyTheme'


export default class Birthday extends Component {
    render() {
        return (
            <div>
                <section className="py-5 bg-breadcrumb">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="breadcrumb-item  text-center">
                                    <h4 className="breadcrumb-title">Birthday Event</h4>
                                    <div>
                                        <ul className="list-unstyled">
                                            <li className="d-inline"><Link to="/">Home</Link></li>
                                            <li className="d-inline"><Link to="/"> / </Link></li>
                                            <li className="d-inline text-white"><Link to="/"></Link>Birthday Event</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="birthday-section py-5">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-10 offset-md-1 text-center">
                                <img src={himg} alt="" />
                                <h2 className="event-heading mt-3">About<span class="text-primary"> Birthday Event</span></h2>
                                <p className="event-subtitle">From Wedding Functions to Birthday Parties or Corporate Events to Musical Functions,<br />
                                    We offer full range of Events Management Services that scale to your needs &amp; budget.
                                </p>
                            </div>
                        </div>

                        <div className="row">
                            <div className="col-md-3">
                                <div class="event-advantages event-advantages-1">
                                    <div class="event-advantages__icon icon-b"><i class="fas fa-hand-holding-usd"></i></div>
                                    <div class="event-advantages__inner">
                                        <h3 class="event-advantages__title">Lowest Price</h3>
                                        <div class="event-advantages__info">Corem ipsum dolor sit amet consectetur elit sed lusm tempor.</div>

                                    </div>
                                </div>
                            </div>
                            <div className="col-md-3">
                                <div class="event-advantages event-advantages-1">
                                    <div class="event-advantages__icon icon-b"><i class="far fa-user"></i></div>
                                    <div class="event-advantages__inner">
                                        <h3 class="event-advantages__title">On Time Always</h3>
                                        <div class="event-advantages__info">Corem ipsum dolor sit amet consectetur elit sed lusm tempor.</div>

                                    </div>
                                </div>
                            </div>
                            <div className="col-md-3">
                                <div class="event-advantages event-advantages-1">
                                    <div class="event-advantages__icon icon-b"><i class="fas fa-award"></i></div>
                                    <div class="event-advantages__inner">
                                        <h3 class="event-advantages__title">All-At-One Place</h3>
                                        <div class="event-advantages__info">Corem ipsum dolor sit amet consectetur elit sed lusm tempor.</div>

                                    </div>
                                </div>
                            </div>
                            <div className="col-md-3">
                                <div class="event-advantages event-advantages-1">
                                    <div class="event-advantages__icon icon-b"><i class="far fa-thumbs-up"></i></div>
                                    <div class="event-advantages__inner">
                                        <h3 class="event-advantages__title">Best Quality Ever</h3>
                                        <div class="event-advantages__info">Corem ipsum dolor sit amet consectetur elit sed lusm tempor.</div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="boys-girls">
                    <div className="container-fluid p-0">
                        <div className="row gx-0">
                            <div className="col-md-6">
                                <div className="boys-b-party text-center">
                                    <h3 >Boys Birthday </h3>
                                    <img src="images/bb.png" alt="Boys-Birthday-Party" />
                                    <p >Make your action man’s next birthday a blast with a Decorations from Party Decorations Jaiour! </p>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="girls-b-party text-center">
                                    <h3 >Girls Birthday </h3>
                                    <img className="img-fluid" src="images/bg.png" alt="Boys-Birthday-Party" />
                                    <p >Make your action man’s next birthday a blast with a Decorations from Party Decorations Jaiour! </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>


                <section className="birthday-section py-5">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-10 offset-md-1 text-center">
                                <img src={himg} alt="" />
                                <h2 className="event-heading mt-3">Our <span class="text-primary"> Services</span></h2>
                                <p className="event-subtitle">From Wedding Functions to Birthday Parties or Corporate Events to Musical Functions,<br />
                                    We offer full range of Events Management Services that scale to your needs &amp; budget.
                                </p>
                            </div>
                        </div>

                        <div className="row text-center pt-3">
                            <div className="col-md-4">
                                <div className="party-services py-2">
                                    <img src="images/cake.png" alt="" />
                                    <h3>Cakes</h3>
                                    <p>We are offering Birthday cakes at your home. Your can order here for cake for lowest price guaranteed.</p>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="party-services py-2">
                                    <img src="images/invitation.png" alt="" />
                                    <h3>Guest Invitation</h3>
                                    <p>We are offering Birthday cakes at your home. Your can order here for cake for lowest price guaranteed.</p>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="party-services py-2">
                                    <img src="images/laugh.png" alt="" />
                                    <h3>Party Fun</h3>
                                    <p>We are offering Birthday cakes at your home. Your can order here for cake for lowest price guaranteed.</p>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="party-services py-2">
                                    <img src="images/party.png" alt="" />
                                    <h3>Party Venue</h3>
                                    <p>We are offering Birthday cakes at your home. Your can order here for cake for lowest price guaranteed.</p>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="party-services py-2">
                                    <img src="images/bunting.png" alt="" />
                                    <h3>Area Decor</h3>
                                    <p>We are offering Birthday cakes at your home. Your can order here for cake for lowest price guaranteed.</p>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="party-services py-2">
                                    <img src="images/hot.png" alt="" />
                                    <h3>Fooding</h3>
                                    <p>We are offering Birthday cakes at your home. Your can order here for cake for lowest price guaranteed.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <PartyTheme />



                <section className="packeages py-5">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-10 offset-md-1 text-center">
                                <img src={himg} alt="" />
                                <h2 className="event-heading mt-3">Event<span class="text-primary"> Packages</span></h2>
                                <p className="event-subtitle">From Wedding Functions to Birthday Parties or Corporate Events to Musical Functions,<br />
                                    We offer full range of Events Management Services that scale to your needs &amp; budget.
                                </p>
                            </div>
                        </div>

                        <div class="row m-auto text-center pt-5">

                            <div class="col-md-4 princing-item red">
                                <div class="pricing-divider">
                                    <h3 class="text-light">Active Package</h3>
                                    <h4 class="my-0 display-4 text-light font-weight-normal mb-3"><span class="h3">$</span> 120 </h4>

                                </div>
                                <div class="card-body bg-white mt-0 shadow">
                                    <ul class="list-unstyled mb-5 position-relative">
                                        <li><b>70</b>  Balloons Area Decor</li>
                                        <li><b>500g</b> 500g SELIBESAN CAKE</li>
                                        <li><b>Birthday </b> CANDLES</li>
                                        <li><b>CAKE TABLE Decoration</b></li>
                                    </ul>
                                    <button type="button" class="btn btn-lg  btn-custom mb-3" onClick={()=> window.open("bookingForm")}>Book Now</button>
                                </div>
                            </div>




                            <div class="col-md-4 princing-item blue">
                                <div class="pricing-divider ">
                                    <h3 class="text-light">Silver Package</h3>
                                    <h4 class="my-0 display-4 text-light font-weight-normal mb-3"><span class="h3">$</span> 250 </h4>

                                </div>

                                <div class="card-body bg-white mt-0 shadow">
                                    <ul class="list-unstyled mb-5 position-relative">
                                        <li><b>70</b>  Balloons Area Decor</li>
                                        <li><b>500g</b> 500g SELIBESAN CAKE</li>
                                        <li><b>Birthday </b> CANDLES</li>
                                        <li><b>CAKE TABLE Decoration</b></li>
                                    </ul>
                                    <button type="button" class="btn btn-lg   btn-custom mb-3" onClick={()=> window.open("bookingForm")}>Book Now</button>
                                </div>
                            </div>






                            <div class="col-md-4 princing-item green">
                                <div class="pricing-divider ">
                                    <h3 class="text-light">Gold Package</h3>
                                    <h4 class="my-0 display-4 text-light font-weight-normal mb-3"><span class="h3">$</span> 250 </h4>

                                </div>

                                <div class="card-body bg-white mt-0 shadow">
                                    <ul class="list-unstyled mb-5 position-relative">
                                        <li><b>70</b>  Balloons Area Decor</li>
                                        <li><b>500g</b> 500g SELIBESAN CAKE</li>
                                        <li><b>Birthday </b> CANDLES</li>
                                        <li><b>CAKE TABLE Decoration</b></li>
                                    </ul>
                                    <button type="button" class="btn btn-lg  btn-custom mb-3" onClick={()=> window.open("bookingForm")}>Book Now</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <Footer />
            </div>
        )
    }
}


















