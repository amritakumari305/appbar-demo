import React, { Component } from 'react'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import './Slider.css';
import himg from '../headicon.png';

export default class PartyTheme extends Component {
    render() {
        const settings = {
            dots: false,
            infinite: true,
            speed: 800,
            autoplay: true,
            slidesToShow: 3,
            slidesToScroll: 1,
            responsive: [
                {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }

            ]
        };
        return (
            <div>
                <section id="events">
                    <div className="container py-4">
                        <div className="row">
                            <div className="col-md-10 offset-md-1 text-center heading-bg">
                                <img src={himg} alt="" />
                                <h2 className="event-heading mt-3">Party <span class="text-primary"> Types </span></h2>
                                <p className="event-subtitle">We make your events smart &amp; impactful by personalised event management services.
                                </p>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-12">

                                <Slider {...settings}>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>Surprise Birthday Party</h5>
                                            <button type="button" class="btn btn-sm btn-primary  btn-custom" onClick={()=> window.open("bookingForm")}>Book Now</button>
                                        </div>
                                    </div>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>Mid-Night Surprise</h5>
                                            <button type="button" class="btn btn-sm btn-primary  btn-custom" onClick={()=> window.open("bookingForm")}>Book Now</button>
                                        </div>
                                    </div>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>Theme Party</h5>
                                            <button type="button" class="btn btn-sm btn-primary  btn-custom" onClick={()=> window.open("bookingForm")}>Book Now</button>
                                        </div>
                                    </div>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>Baloon Decoration</h5>
                                            <button type="button" class="btn btn-sm btn-primary  btn-custom" onClick={()=> window.open("bookingForm")}>Book Now</button>
                                        </div>
                                    </div>
                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>Flower Decoration</h5>
                                            <button type="button" class="btn btn-sm btn-primary  btn-custom" onClick={()=> window.open("bookingForm")}>Book Now</button>
                                        </div>
                                    </div>

                                    <div className="sld-cls">
                                        <img class="img-fluid" src="images/services/s1.jpg" />
                                        <div className="event-descriptions">
                                            <h5>Customised Party</h5>
                                            <button type="button" class="btn btn-sm btn-primary  btn-custom" onClick={()=> window.open("bookingForm")}>Book Now</button>
                                        </div>
                                    </div>
                                    

                                </Slider>

                            </div>
                        </div>
                    </div>
                </section>
            </div>
        )
    }
}
