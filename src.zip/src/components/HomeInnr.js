import React, { Component } from 'react';
import './Slider.css';
import himg from '../headicon.png';
import { Link } from 'react-router-dom';
// import { Button } from 'react-bootstrap';

export default class HomeInnr extends Component {
    render() {
        return (
            <>
                <section id="about">
                    <div className="container py-4">
                        <div className="row">
                            <div className="col-md-10 offset-md-1 text-center">
                                <img src={himg} alt="" />
                                <h2 className="event-heading mt-3">Welcome to<span class="text-primary"> Coral Event</span></h2>
                                <p className="event-subtitle">From Wedding Functions to Birthday Parties or Corporate Events to Musical Functions,<br />
                                    We offer full range of Events Management Services that scale to your needs &amp; budget.
                                </p>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-4">
                                <div class="event-advantages event-advantages-1">
                                    <div class="event-advantages__icon text-primary"><i class="fas fa-puzzle-piece"></i></div>
                                    <div class="event-advantages__inner">
                                        <h3 class="event-advantages__title">Great Services</h3>
                                        <div class="event-advantages__info">Corem ipsum dolor sit amet consectetur elit sed lusm tempor incididunt ut labore et dolore mag aliqua enima minim veniam quis nostrud exercitation</div>

                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div class="event-advantages event-advantages-1">
                                    <div class="event-advantages__icon text-primary"><i class="far fa-user"></i></div>
                                    <div class="event-advantages__inner">
                                        <h3 class="event-advantages__title">Great People</h3>
                                        <div class="event-advantages__info">Corem ipsum dolor sit amet consectetur elit sed lusm tempor incididunt ut labore et dolore mag aliqua enima minim veniam quis nostrud exercitation</div>

                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div class="event-advantages event-advantages-1">
                                    <div class="event-advantages__icon text-primary"><i class="far fa-thumbs-up"></i></div>
                                    <div class="event-advantages__inner">
                                        <h3 class="event-advantages__title">Great Ideas</h3>
                                        <div class="event-advantages__info">Corem ipsum dolor sit amet consectetur elit sed lusm tempor incididunt ut labore et dolore mag aliqua enima minim veniam quis nostrud exercitation</div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section id="services">
                    <div className="container py-4">
                        <div className="row">
                            <div className="col-md-10 offset-md-1 text-center">
                                <img src={himg} alt="" />
                                <h2 className="event-heading mt-3">Coral Event<span class="text-primary"> Services </span></h2>
                                <p className="event-subtitle">We make your events smart &amp; impactful by personalised event management services.
                                </p>
                            </div>
                        </div>


                        <div className="row">
                            <div className="col-md-4">
                                <div class="services-imagebox static-title mb-4">
                                    <div class="services-thumbnail">
                                        <img class="img-fluid" src="images/services/s1.jpg" alt="" />
                                    </div>
                                    <div class="services-content">
                                        <div class="services-title">
                                            <h5><Link to={"/"}> Birthday Event</Link></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div class="services-imagebox static-title mb-4">
                                    <div class="services-thumbnail">
                                        <img class="img-fluid" src="images/services/s2.jpg" alt="" />
                                    </div>
                                    <div class="services-content">
                                        <div class="services-title">
                                            <h5><Link to={"/"}> Private Party</Link></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div class="services-imagebox static-title mb-4">
                                    <div class="services-thumbnail">
                                        <img class="img-fluid" src="images/services/s3.jpg" alt="" />
                                    </div>
                                    <div class="services-content">
                                        <div class="services-title">
                                            <h5><Link to={"/"}> Baby Shower</Link></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div class="services-imagebox static-title mb-4">
                                    <div class="services-thumbnail">
                                        <img class="img-fluid" src="images/services/s4.jpg" alt="" />
                                    </div>
                                    <div class="services-content">
                                        <div class="services-title">
                                            <h5><Link to={"/"}> Anniversary Party</Link></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div class="services-imagebox static-title mb-4">
                                    <div class="services-thumbnail">
                                        <img class="img-fluid" src="images/services/s5.jpg" alt="" />
                                    </div>
                                    <div class="services-content">
                                        <div class="services-title">
                                            <h5><Link to={"/"}> Festival Event</Link></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div class="services-imagebox static-title mb-4">
                                    <div class="services-thumbnail">
                                        <img class="img-fluid" src="images/services/s6.jpg" alt="" />
                                    </div>
                                    <div class="services-content">
                                        <div class="services-title">
                                            <h5><Link to={"/"}> Engagement Party</Link></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>

                <section class="process-section bg-img8 process-bgcolor-black process-bg process-bgimage-yes pt-5">
                    <div class="process-wrapper-bg-layer process-bg-layer"></div>
                    <div class="container">
                        <div className="row">
                            <div className="col-md-10 offset-md-1 text-center heading-bg">
                                <img src={himg} alt="" />
                                <h2 className="event-heading mt-3 text-white">Our Working <span class="text-primary"> Process </span></h2>
                                <p className="event-subtitle text-white">We make your events smart &amp; impactful by personalised event management services.
                                </p>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-3">
                                <div class="process-box text-center">
                                    <div class="icon-outline-border">
                                        <div class="process-box-icon">
                                            <div class="process-icon process-icon_element-size-lg process-icon_element-fill process-icon_element-background-skincolor process-icon_element-style-rounded">
                                                <i class="fas fa-hotel"></i>
                                            </div>
                                        </div>
                                        <div class="process-title process-textcolor-white">
                                            <h5>Find The Perfect Venue <br />For Free</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="process-box text-center">
                                    <div class="icon-outline-border">
                                        <div class="process-box-icon">
                                            <div class="process-icon process-icon_element-size-lg process-icon_element-fill process-icon_element-background-skincolor process-icon_element-style-rounded">
                                                <i class="fas fa-user-check"></i>
                                            </div>
                                        </div>
                                        <div class="process-title process-textcolor-white">
                                            <h5>Connect with the best <br />vendor</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="process-box text-center">
                                    <div class="icon-outline-border">
                                        <div class="process-box-icon">
                                            <div class="process-icon process-icon_element-size-lg process-icon_element-fill process-icon_element-background-skincolor process-icon_element-style-rounded">
                                                <i class="fas fa-hand-holding-heart"></i>
                                            </div>
                                        </div>
                                        <div class="process-title process-textcolor-white">
                                            <h5>Let us help you with <br />the event</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="process-box text-center">
                                    <div class="icon-outline-border">
                                        <div class="process-box-icon">
                                            <div class="process-icon process-icon_element-size-lg process-icon_element-fill process-icon_element-background-skincolor process-icon_element-style-rounded">
                                                <i class="fas fa-music"></i>
                                            </div>
                                        </div>
                                        <div class="process-title process-textcolor-white">
                                            <h5>Enjoy the party with <br />your friends</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <div class="my-3">
                                    <Link class="process-btn process-btn-size-md process-btn-shape-round process-btn-style-border process-btn-color-white mt-2" to="/">Book Event</Link>
                                    <Link class="process-btn process-btn-size-md process-btn-shape-round process-btn-style-fill process-btn-color-skincolor mt-2" to="/" title="">Our Gallery</Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

               

                

                

            </>
        )
    }
}
