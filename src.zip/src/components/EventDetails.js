import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Carousel } from 'react-bootstrap';
import './Slider.css';
import Footer from './Footer';

export default class EventDetails extends Component {
    render() {
        return (
            <>
                <section className="py-5 bg-breadcrumb">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="breadcrumb-item  text-center">
                                    <h4 className="breadcrumb-title">Event Details</h4>
                                    <div>
                                        <ul className="list-unstyled">
                                            <li className="d-inline"><Link to="/">Home</Link></li>
                                            <li className="d-inline"><Link to="/"> / </Link></li>
                                            <li className="d-inline text-white"><Link to="/"></Link>Event Details</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="evt-full-decs py-5">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-9 mb-3">
                                <div className="event-discriptions box-shadow">
                                    <div className="event-sliders">
                                        <Carousel>
                                            <Carousel.Item interval={2000}>
                                                <img
                                                    className="w-100"
                                                    src="images/s1.jpg"
                                                    alt="One"
                                                />
                                                <Carousel.Caption>
                                                    {/* <h3>Label for first slide</h3>
                                <p>Sample Text for Image One</p> */}
                                                </Carousel.Caption>
                                            </Carousel.Item>
                                            <Carousel.Item interval={2000}>
                                                <img
                                                    className="w-100"
                                                    src="images/s2.jpg"
                                                    alt="Two"
                                                />
                                                <Carousel.Caption>
                                                    {/* <h3>Label for second slide</h3>
                                <p>Sample Text for Image Two</p> */}
                                                </Carousel.Caption>
                                            </Carousel.Item>
                                            <Carousel.Item interval={2000}>
                                                <img
                                                    className="w-100"
                                                    src="images/s3.jpg"
                                                    alt="Two"
                                                />
                                                <Carousel.Caption>
                                                    {/* <h3>Label for second slide</h3>
                                <p>Sample Text for Image Two</p> */}
                                                </Carousel.Caption>
                                            </Carousel.Item>
                                        </Carousel>
                                    </div>
                                    <div className="event-details-box">
                                        <div className="post-meta">
                                            <ul className="list-inline">
                                                <li><Link to="/">20 Aug, 2021</Link></li>

                                            </ul>
                                        </div>
                                        <h4 class="pt-10">Rerum facilis est et expedita distinctio</h4>
                                        <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from “de Finibus Bonorum et Malorum” by Cicero are also reproducmpanied by English versions from the 1914 translation by H. Raby Cicero are also reproducmpanied.by Enloons from the 1914 translation by H.<b>Raby Cicero are also companied versions</b> from tckham.</p>
                                        <ul class="pl-15">
                                            <li class="list-style-circle pt-6">Rerum facilis est et expedita distinctio nam libero</li>
                                            <li class="list-style-circle pt-6">Lorem Ipsum has been the industry’s standard</li>
                                            <li class="list-style-circle pt-6">qui dolorem ipsum quia dolor sit amet, sed tempora</li>
                                            <li class="list-style-circle pt-6">Lorem Ipsum has been the industry’s standard</li>
                                        </ul>
                                        <div className="row">
                                            <div className="col-md-4 mb-2">
                                                <img src="images/s2.jpg" width="100%" alt="event1" />
                                            </div>
                                            <div className="col-md-4 mb-2">
                                                <img src="images/s2.jpg" width="100%" alt="event2" />
                                            </div>
                                            <div className="col-md-4 mb-2">
                                                <img src="images/s2.jpg" width="100%" alt="event3" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-3 event-sidebar">
                                <aside class="widget widget-recent-post">
                                    <h3 class="widget-title">Recent posts</h3>
                                    <ul class="evt-recent-post-list">
                                        <li class="evt-recent-post-list-li clearfix">
                                            <Link><img src="images/s3.jpg" alt="blog-img" /></Link>
                                            <Link>Best Kids’ Birthday Party Ideas</Link>
                                            <span class="post-date">October 1, 2018</span>
                                        </li>
                                        <li class="evt-recent-post-list-li clearfix">
                                            <Link><img src="images/s3.jpg" alt="blog-img" /></Link>
                                            <Link>Best Kids’ Birthday Party Ideas</Link>
                                            <span class="post-date">October 1, 2018</span>
                                        </li>
                                        <li class="evt-recent-post-list-li clearfix">
                                            <Link><img src="images/s3.jpg" alt="blog-img" /></Link>
                                            <Link>Best Kids’ Birthday Party Ideas</Link>
                                            <span class="post-date">October 1, 2018</span>
                                        </li>
                                    </ul>
                                </aside>
                                <aside class="widget widget-Categories">
                                    <h3 class="widget-title">Categories</h3>
                                    <ul class="widget-menu">
                                        <li><Link to="/"> <i className="fas fa-angle-right"></i> Engagement</Link></li>
                                        <li><Link to="/"><i className="fas fa-angle-right"></i> Birthday</Link></li>
                                        <li><Link to="/"><i className="fas fa-angle-right"></i> Babyshower</Link></li>
                                        <li><Link to="/"> <i className="fas fa-angle-right"></i> Aniversary</Link></li>
                                        <li><Link to="/"><i className="fas fa-angle-right"></i> Private Party</Link></li>
                                        <li><Link to="/"><i className="fas fa-angle-right"></i> Festival </Link></li>

                                    </ul>
                                </aside>
                                <aside class="widget widget_media_image p-0">
                                    <Link to="/"><img class="img-fluid" src="images/banner-img.png" alt="banner-image" /></Link>
                                </aside>

                            </div>
                        </div>
                    </div>
                </section>

                <Footer />
            </>
        )
    }
}
